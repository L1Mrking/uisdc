function search(){
    let obj1 = document.getElementById("searchBox");
    let val1 = obj1.style.display;
    if (val1=='none'){
        obj1.style.display="block";
    } else{
        obj1.style.display="none";
    }
}
function clo() {
    let obj2 = document.getElementById("login");
    obj2.style.display="none";
}
function ope() {
    let obj3 = document.getElementById("login");
    obj3.style.display="block";
}

let picwid = 998 ,key = 0;
let left = document.getElementById("goPre");
let right = document.getElementById("goNext");
let list = document.getElementById("piclist");
left.onclick = () =>{
    key--;
    if(key<0){
        key = 2;
    }
    list.style.left = -key*picwid+'px';
}
right.onclick = () =>{
    key++;
    if(key > 2){
        key = 0;
    }
    list.style.left = -key*picwid+'px';
}
setInterval(function(){
    key++;
    if(key > 2){
        key = 0;
    }
    list.style.left = -key*picwid+'px'
},2000)


let divwid = 325,index = 0 ;
let goleft = document.getElementById("left");
let goright = document.getElementById("right");
let showlist = document.getElementById("l-showlist");
goleft.onclick = () =>{
    index--;
    if(index < 0){
        index = 1;
    }
    showlist.style.left = -index*divwid+'px';
}
goright.onclick = () =>{
    index++;
    if(index > 1){
        index = 0;
    }
    showlist.style.left = -index*divwid+'px';
}


let rdivwid = 309,rindex = 0 ;
let toleft = document.getElementById("toleft");
let toright = document.getElementById("toright");
let rshowlist = document.getElementById("r-showlist");
toleft.onclick = () =>{
    rindex--;
    if(rindex < 0){
        rindex = 5;
    }
    rshowlist.style.left = -rindex*rdivwid+'px';
}
toright.onclick = () =>{
    rindex++;
    if(rindex > 5){
        rindex = 0;
    }
    rshowlist.style.left = -rindex*rdivwid+'px';
}



let tol = document.getElementById("tol");
let tor = document.getElementById("tor");
let object = document.getElementById("object");
let objecttop = document.getElementById("object-top");
let objectfoot = document.getElementById("object-foot") 
tol.onclick = () =>{
    objecttop.style.display = "block";
    objectfoot.style.display = "none";
    tor.style.display = "block";
    tol.style.display = "none";
    object.style.top = 0+'px';
} 
tor.onclick = () =>{
    objecttop.style.display = "none";
    objectfoot.style.display = "block";
    tor.style.display = "none";
    tol.style.display = "block";
}


let newessay = document.getElementById("newessay");
let recenthot = document.getElementById("recenthot");
let showessay = document.getElementById("showessay");
let showhot = document.getElementById("showhot");
newessay.onclick = () =>{
    showessay.style.display = "flex";
    showhot.style.display = "none";
    newessay.style.color = "rgb(245, 81, 6)";
    recenthot.style.color = "black";
}
recenthot.onclick = () =>{
    showessay.style.display = "none";
    showhot.style.display = "flex";
    newessay.style.color = "black";
    recenthot.style.color = "rgb(245, 81, 6)";
}


let back = document.getElementById("back");
back.onclick =() => {
    document.body.scrollTop = document.documentElement.scrollTop = 0;
}